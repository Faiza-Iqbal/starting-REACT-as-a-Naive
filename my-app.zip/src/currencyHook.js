import logo from './logo.svg';
import './App.css';
import {useState, useEffect} from 'react';
function useCurrencyConverter(inputAmount) {
  const [currency, setCurrency] = useState(inputAmount);
  function transformCurrency(amount){
    amount = Math.round(amount);
    if (amount >= 100000 && amount < 10000000) {
        amount = amount / 100000;
        amount = Math.round(amount * 100) / 100
        return amount + " lac";
    } else if(amount >= 10000000) {
        amount = amount / 10000000;
        amount = Math.round(amount * 100) / 100
        return amount + " crore";
    }
    return amount;
  }
  useEffect(() => {
     setCurrency(transformCurrency(inputAmount));
  }
);
  return currency;
}
export default useCurrencyConverter;
