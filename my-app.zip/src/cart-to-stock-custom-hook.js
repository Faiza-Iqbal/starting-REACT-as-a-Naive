import logo from './logo.svg';
import './App.css';
import {useState, useEffect} from 'react';
function useCartStockHook(itemId) {
  const itemsList = [{id: 1, stock:20},{id: 2, stock:25}, {id: 3, stock:10}];
  const [items, setItems] = useState(0);
    setItems(itemsCount);
    return items;
}

export default useCartStockHook;
