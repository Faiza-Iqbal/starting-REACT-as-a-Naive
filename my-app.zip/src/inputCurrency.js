import logo from './logo.svg';
import './App.css';
import {useState} from 'react';
import useCurrencyConverter from './currencyHook';
function CheckCurrency() {
  const [currencyState, setCurrencyState] = useState('');
  const currencyInWords = useCurrencyConverter(currencyState);
  return (
      <div>
        <h1>Your Amount</h1>
        <input type="tel" value={currencyState} onChange = {(e) => setCurrencyState(Number(e.target.value))} />
        <h2>{currencyInWords}</h2>
      </div>
  );
}
export default CheckCurrency;
