import logo from './logo.svg';
import './App.css';
import {useState} from 'react';
function DisplayComponent() {
  return (
    <h1> Hello World! </h1>
  );
}

export default DisplayComponent;
