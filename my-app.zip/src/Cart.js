import logo from './logo.svg';
import './App.css';
import {useState} from 'react';
function Cart() {
  // const itemCount = useCartStockHook(item);
  // return (
  //     <div>
  //     <h1>Your Cart</h1>
  //     <p> No. of items: {itemCount}</p>
  //     <button onClick = {() => setItemCount(itemCount+1)}>Add to Cart </button>
  //     </div>
  // );
}

export default Cart;
