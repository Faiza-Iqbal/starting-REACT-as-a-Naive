import React from "react";
// Importing components from project directory
import HeaderComponent from "../../Header/Header";
import MultipleOptions from "./MultipleOptions/MultipleOptions";
import QuestionTitle from "./QuestionTitle/QuestionTitle";
import Action from "./Action/Action";

//Data List
const options = [
  {
    label: "Option 1",
    value: "A",
    inputBox: false,
    selected: false,
  },
  {
    label: "Option 2",
    value: "B",
    inputBox: false,
    selected: false,
  },
  {
    label: "Option 3",
    value: "C",
    inputBox: false,
    selected: false,
  },
  {
    label: "Option 4",
    value: "D",
    inputBox: false,
    selected: false,
  },
  {
    label: "Other",
    value: "other",
    inputBox: true,
    selected: false,
  },
];
function MultipleChoiceQuestion() {
  return (
    <>
      <HeaderComponent />
      <QuestionTitle />
      {
        <>
          <MultipleOptions list={options} />
          <Action />
        </>
      }
    </>
  );
}

export default MultipleChoiceQuestion;
