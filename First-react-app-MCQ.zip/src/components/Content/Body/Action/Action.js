import "./Action.css";

const Action = () => (
  <div className="nextWrapper">
    <input className="nextButton" type="submit" name="submit" value="next" />
  </div>
);

export default Action;
