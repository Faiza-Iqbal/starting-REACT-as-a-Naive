import "./QuestionTitle.css";

const Title = () => <p className="questionTitle">Question 1</p>;

export default Title;
