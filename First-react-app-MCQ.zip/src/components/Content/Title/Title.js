import "./Title.css";

const QuestionTitle = () => (
  <div className="questionBody">
    <p>Select maximum 2 options</p>
  </div>
);

export default QuestionTitle;
