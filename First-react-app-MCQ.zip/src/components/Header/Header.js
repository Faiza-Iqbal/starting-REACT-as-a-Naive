import "./Header.css";

const HeaderComponent = () => (
  <div className={"questionHeader"}>
    <p>Survey-Question 1/4 </p>
  </div>
);

export default HeaderComponent;
