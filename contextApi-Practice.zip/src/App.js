import logo from './logo.svg';
import './App.css';
import React from 'react';
const ColorContext = React.createContext('orange');
function App() {
    return(
      <div>
        <p>test app  </p>
        <App1 />
      </div>
    );
}
function App1(){
  return (
    <div>
      <ColorContext.Provider value='blue'>
      <App2 />
      </ColorContext.Provider>
      <p>I am doing nothing! </p>
    </div>
  )
}
class App2 extends React.Component{
  static contextType = ColorContext;
  render(){
    return (
      <div>
        <h1 style = {{color : this.context}}>Hello World!</h1>
        <App3 />
      </div>
    );
  }
}
function App3(){
  return(
    <ColorContext.Provider value='red'>
    <App4 />
    </ColorContext.Provider>
  );
}
class App4 extends React.Component {
  static contextType = ColorContext;
  render(){
    return(
      <h2 style = {{color: this.context}} >Context Changed! </h2>
    );
  }
}
export default App;
